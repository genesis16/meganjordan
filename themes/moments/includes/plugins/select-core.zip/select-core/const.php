<?php

define( 'QODE_CORE_VERSION', '1.3' );
define( 'QODE_CORE_ABS_PATH', dirname( __FILE__ ) );
define( 'QODE_CORE_REL_PATH', dirname( plugin_basename( __FILE__ ) ) );
define( 'QODE_CORE_CPT_PATH', QODE_CORE_ABS_PATH . '/post-types' );
define( 'QODE_CORE_OPTIONS_NAME', 'qode_options_moments' );
define( 'QODE_CORE_URL_PATH', plugin_dir_url( __FILE__ ) );