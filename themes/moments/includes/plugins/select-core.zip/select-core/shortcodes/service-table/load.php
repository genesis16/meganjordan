<?php

include_once QODE_CORE_ABS_PATH.'/shortcodes/service-table/service-tables.php';
include_once QODE_CORE_ABS_PATH.'/shortcodes/service-table/service-table.php';