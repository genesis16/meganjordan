<?php

include_once QODE_CORE_ABS_PATH.'/shortcodes/cover-boxes/cover-boxes.php';