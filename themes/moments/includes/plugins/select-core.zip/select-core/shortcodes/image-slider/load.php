<?php
include_once QODE_CORE_ABS_PATH.'/shortcodes/image-slider/image-slider.php';